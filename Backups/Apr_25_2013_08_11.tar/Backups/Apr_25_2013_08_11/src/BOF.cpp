/*
 * BOF.cpp
 *
 *  Created on: Apr 25, 2013
 *      Author: bhikadiy
 */

#include "BOF.h"

void BOF::trainvocab()
{
	SIFT sift(1000);
	vector<KeyPoint> key_points;
	Mat descriptors;
	Mat training_desriptor;

    std::ofstream object_file;
    object_file.open("/s/chopin/l/grad/bhikadiy/Jazz/CS510/workspace/Assignment-4/data/SIFT_OUTPUT_FIXED/desciptor_sizes.txt");


    object_file<<std::setw(25)<<"Image Name"<<std::setw(10)<<"no. of descriptors\n";

    for(unsigned int i=0;i<set.size();i++)
    {
    	//std::cout<<"\nworking on "<<set.at(i).getname();
    	/*calculating sift descriptors*/
    	Mat temp=set.at(i).getme().clone(), output_img;
    	sift(temp, Mat(), key_points, descriptors);
    	drawKeypoints(temp, key_points, output_img);

    	/*writing files */
   /* 	std::stringstream filename,path;
    	filename<<set.at(i).getname();
    	object_file<<std::setw(25)<<set.at(i).getname()<<std::setw(10)<<descriptors.rows<<"x"<<descriptors.cols<<std::endl;
    	filename<<".jpg";
    	path<<"/s/chopin/l/grad/bhikadiy/Jazz/CS510/workspace/Assignment-4/data/SIFT_OUTPUT_FIXED/"<<filename.str();
    	//std::cout<<path.str()<<std::endl;
    	imwrite(path.str(),output_img);*/

    	//add descriptors to training set
    	training_desriptor.push_back(descriptors);
    	std::cout<<"\nno of desriptors "<<descriptors.rows<<"\n training set size is "<<training_desriptor.rows<<"x"<<training_desriptor.cols;
    }












/*

	namedWindow("Image");
	imshow("Image", output_img);
	waitKey(0);
	destroyWindow("Image");
	std::cout<<descriptors.rows<<"x"<<descriptors.cols;
*/



/*
	Ptr<FeatureDetector> featureDetector = FeatureDetector::create("SIFT");
	Ptr<DescriptorExtractor> descExtractor = DescriptorExtractor::create( "SIFT" );
	Ptr<BOWImgDescriptorExtractor> bowExtractor;

	const int elemSize = CV_ELEM_SIZE(descExtractor->descriptorType());
	 const int descByteSize = descExtractor->descriptorSize() * elemSize;
	        const int bytesInMB = 1048576;
	        const int maxDescCount = (200 * bytesInMB) / descByteSize;
	        RNG& rng = theRNG();

	TermCriteria terminate_criterion;
	terminate_criterion.epsilon = FLT_EPSILON;
	BOWKMeansTrainer bowTrainer( 1000, terminate_criterion, 3, KMEANS_PP_CENTERS );

	for(unsigned int i=0; i<set.size();i++)
	{
		vector<KeyPoint> imageKeypoints;
		featureDetector->detect(set.at(i).getme().clone(),imageKeypoints);

		Mat imageDescriptors;
		descExtractor->compute( set.at(i).getme().clone(), imageKeypoints, imageDescriptors );


		if( !imageDescriptors.empty() )
		{

			int descCount = imageDescriptors.rows;
			// Extract trainParams.descProportion descriptors from the image, breaking if the 'allDescriptors' matrix becomes full
			int descsToExtract = static_cast<int>(0.3 * static_cast<float>(descCount));
			// Fill mask of used descriptors
			vector<char> usedMask( descCount, false );


		}
	}
	Mat vocabulary = bowTrainer.cluster();
	std::cout<<vocabulary<<"done";*/


}


BOF::~BOF() {
	// TODO Auto-generated destructor stub
}

