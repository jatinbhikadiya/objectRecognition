/*
 * read.h
 *
 *  Created on: Feb 4, 2013
 *      Author: bhikadiy
 */
#ifndef READ_H_
#define READ_H_


#include "includes.h"
#include "Img.h"

class reader
{
	 std::vector<Img> &img, &templates;
public:
	reader();
	reader(std::vector<Img>&i, std::vector<Img>&t):img(i),templates(t){};
	void image_read(std::vector<std::string>);
	void template_read(std::vector<std::string>);
	void push_data(std::string,unsigned int);
	void push_temp(std::string,unsigned int);
	virtual ~reader();
};

#endif /* READ_H_ */
