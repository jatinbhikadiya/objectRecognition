/*
 * BOF.h
 *
 *  Created on: Apr 25, 2013
 *      Author: bhikadiy
 */

#ifndef BOF_H_
#define BOF_H_
#include "includes.h"
#include "Img.h"
class BOF {

	std::vector<Img> &set;

public:
	BOF();
	BOF(std::vector<Img>&i):set(i){};
	void trainvocab();
	virtual ~BOF();
};

#endif /* BOF_H_ */
