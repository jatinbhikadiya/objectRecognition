/*
 * BOF.h
 *
 *  Created on: Apr 25, 2013
 *      Author: bhikadiy
 */

#ifndef BOF_H_
#define BOF_H_
#include "includes.h"
#include "Img.h"
class BOF {

	std::vector<Img> &set;
	std::vector<std::pair<std::string,int> >set_list;
	Mat vocabulary;

public:
	BOF();
	BOF(std::vector<Img>&i,std::vector<std::pair<std::string,int> >s):set(i),set_list(s){};
	void trainvocab();

	void test(std::vector<Img>&);

	void confusinmatrix(std::vector<std::string>,std::vector<std::string>);
	virtual ~BOF();
};

#endif /* BOF_H_ */
