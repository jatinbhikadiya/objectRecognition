/*
 * includes.h
 *
 *  Created on: Apr 22, 2013
 *      Author: bhikadiy
 */

#ifndef INCLUDES_H_
#define INCLUDES_H_
#include <string>
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include <opencv2/opencv.hpp>
#include <opencv2/nonfree/nonfree.hpp>
using namespace cv;



#endif /* INCLUDES_H_ */
